#!/usr/bin/env bash
# Diagnose and fix USB permissions for the AlienFX controller (187c:0551).
# Safe to re-run; reinstalls the udev rule each time.

set -uo pipefail
cd "$(dirname "$(readlink -f "$0")")"

VID=187c
PID=0551

locate_node() {
    # Parse `lsusb` output like: "Bus 003 Device 003: ID 187c:0551 ..."
    local line bus dev
    line=$(lsusb -d "${VID}:${PID}" 2>/dev/null | head -n1)
    [[ -z "$line" ]] && return 1
    bus=$(awk '{print $2}' <<<"$line")
    dev=$(awk '{sub(":",""); print $4}' <<<"$line")
    echo "/dev/bus/usb/${bus}/${dev}"
}

hr() { printf -- '--- %s %s\n' "$1" "$(printf '%*s' $((60 - ${#1})) '' | tr ' ' '-')"; }

hr "lsusb"
lsusb -d "${VID}:${PID}" || echo "NOT FOUND — is the machine actually an Alienware Area-51?"

node=$(locate_node || true)
hr "device node"
if [[ -n "${node:-}" ]]; then
    echo "path: $node"
    ls -l "$node" || true
else
    echo "(could not determine device node)"
fi

hr "loginctl sessions"
loginctl list-sessions 2>/dev/null || echo "(loginctl unavailable)"

hr "reinstalling udev rule"
./install-udev.sh

# udev settle so the retrigger finishes before we look again
sudo udevadm settle || true

hr "device node after rule reinstall"
node=$(locate_node || true)
if [[ -n "${node:-}" ]]; then
    ls -l "$node" || true
else
    echo "(device node missing after retrigger — check dmesg)"
fi

hr "probe"
./start.sh --probe || true

echo
echo "If probe still fails with 'Access denied', paste the full output above."
