#!/usr/bin/env bash
# Dump the AlienFX controller's USB+HID descriptors so we can confirm
# the report layout (Output vs Feature, report IDs, sizes).

set -uo pipefail

VID=187c
PID=0551

hr() { printf -- '--- %s %s\n' "$1" "$(printf '%*s' $((60 - ${#1})) '' | tr ' ' '-')"; }

hr "lsusb summary"
lsusb -d "${VID}:${PID}"

hr "lsusb -v (HID descriptors)"
sudo lsusb -v -d "${VID}:${PID}" 2>/dev/null | sed -n '/HID Device Descriptor/,/^$/p; /Endpoint Descriptor/,/^$/p'

hr "report descriptor (raw)"
if command -v usbhid-dump >/dev/null 2>&1; then
    sudo usbhid-dump -m "${VID}:${PID}" -e descriptor
else
    echo "usbhid-dump not installed (sudo dnf install usbutils)"
fi

hr "python test write (Feature report ID 2, reset-all-on)"
python3 <<'EOF'
import sys
try:
    import usb.core
except ImportError:
    sys.exit("pyusb missing")

dev = usb.core.find(idVendor=0x187c, idProduct=0x0551)
if dev is None:
    sys.exit("device not found")
try:
    if dev.is_kernel_driver_active(0):
        dev.detach_kernel_driver(0)
except Exception:
    pass

# Try a Feature report SET first, then GET, on report id 2
pkt = bytes([0x02, 0x07, 0x04, 0, 0, 0, 0, 0, 0])   # RESET, all-lights-on
try:
    dev.ctrl_transfer(0x21, 0x09, 0x0302, 0, pkt, 1000)
    print("Feature SET_REPORT ok")
except Exception as e:
    print(f"Feature SET_REPORT failed: {e}")
try:
    data = dev.ctrl_transfer(0xA1, 0x01, 0x0302, 0, 9, 1000)
    print("Feature GET_REPORT ->", " ".join(f"{b:02x}" for b in data))
except Exception as e:
    print(f"Feature GET_REPORT failed: {e}")
EOF
