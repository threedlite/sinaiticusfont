#!/usr/bin/env bash
# Install rgb-weather as a systemd user service that auto-starts on boot.
# Idempotent — safe to re-run.

set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"

UNIT_SRC="$PWD/rgb-weather.service"
UNIT_DIR="$HOME/.config/systemd/user"
UNIT_DST="$UNIT_DIR/rgb-weather.service"

if [[ ! -f "$UNIT_SRC" ]]; then
    echo "error: $UNIT_SRC not found" >&2
    exit 1
fi

mkdir -p "$UNIT_DIR"
cp "$UNIT_SRC" "$UNIT_DST"
echo "installed unit: $UNIT_DST"

systemctl --user daemon-reload
systemctl --user enable --now rgb-weather.service

# Without linger, user services stop when you log out and don't start at boot
# unless you log in. Linger makes the service start at boot.
if ! loginctl show-user "$USER" 2>/dev/null | grep -q "Linger=yes"; then
    echo "enabling linger (sudo required) so the service runs without login..."
    sudo loginctl enable-linger "$USER"
fi

echo
echo "Service status:"
systemctl --user status rgb-weather.service --no-pager -n 5 || true

cat <<'EOF'

Useful commands:
  systemctl --user status rgb-weather       # check status
  systemctl --user restart rgb-weather      # restart
  systemctl --user stop rgb-weather         # stop until next boot
  systemctl --user disable --now rgb-weather   # remove autostart
  journalctl --user -u rgb-weather -f       # live log
EOF
