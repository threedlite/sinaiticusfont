#!/usr/bin/env bash
# Launcher. Passes through any flags to rgb_weather.py
# Examples:
#   ./start.sh              # normal weather loop
#   ./start.sh --cycle      # debug: cycle through colors
#   ./start.sh --probe      # verify USB access and exit

set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"

if ! python3 -c "import usb.core" 2>/dev/null; then
    echo "error: pyusb not installed. Install with:" >&2
    echo "       sudo dnf install python3-pyusb" >&2
    exit 1
fi

if [[ ! -r /etc/udev/rules.d/99-alienfx.rules ]]; then
    echo "note: /etc/udev/rules.d/99-alienfx.rules not found." >&2
    echo "      If you hit USBError: Access denied, install the rule (see README)." >&2
fi

exec python3 ./rgb_weather.py "$@"
