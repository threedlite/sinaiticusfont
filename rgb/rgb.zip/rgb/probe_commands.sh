#!/usr/bin/env bash
# Blind probe of candidate AWCC command bytes. Watch the chassis lights
# while this runs — ANY flicker or color change is a clue. Each packet
# gets 1.5s to show an effect before the next one is sent.

set -u
cd "$(dirname "$(readlink -f "$0")")"

PY=/home/user/rgb/rgb_weather.py
DWELL=1.5

send() {
    local label="$1"; shift
    echo
    echo "=== $label ==="
    echo "   pkt: $*"
    python3 "$PY" --raw "$*" 2>&1 | grep -v "status err" || true
    sleep "$DWELL"
}

echo "Probing 187c:0551 for a command set that causes any visible change."
echo "Watch your chassis lights. Note any response (timing + what changed)."
echo

# --- AWCC-style "init" / "ping" patterns -----------------------------------
send "awcc ping 02 01"                  02 01
send "awcc ping 02 0A"                  02 0A
send "awcc ping 02 10"                  02 10
send "awcc version 02 20"               02 20
send "awcc handshake 02 CC 01"          02 CC 01

# --- Candidate 'set all zones red' under various layouts -------------------
# 8-bit color (R, G, B raw) at various offsets
send "set-color v1 FF0000"              02 03 00 ff 00 00
send "set-color v2 FF0000 at [3-5]"     02 03 01 ff 00 00 00 00 00
send "set-color v3 zone=0 R G B"        02 13 00 ff 00 00
send "set-color v4 zone=FF R G B"       02 13 ff ff 00 00

# AWCC v2 (T-Troll doc style): 02 CC <cmd> ...
send "awcc-v2 set color all"            02 CC 03 00 00 ff 00 00
send "awcc-v2 set brightness"           02 CC 0c ff

# Newer 'ELC' patterns seen in firmware strings online
send "elc-style A0 01 FF0000"           a0 01 ff 00 00
send "elc-style 02 A0 01 FF0000"        02 a0 01 ff 00 00

# --- Pure reset / apply attempts -------------------------------------------
send "apply / execute 02 CC 06"         02 cc 06
send "apply 02 CC 04"                   02 cc 04
send "factory reset 02 CC 00"           02 cc 00

echo
echo "Probe complete. Did anything visibly change? If yes, note which"
echo "'===' block was active at the moment and we'll narrow down from there."
