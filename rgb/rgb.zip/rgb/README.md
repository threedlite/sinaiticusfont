# rgb-weather

Drive Alienware chassis lighting to a color reflecting the current weather at
a given airport. Self-contained Python (stdlib + pyusb), no daemon, no external
RGB control software needed.

Verified working on:

- **Alienware Area-51 R8 (AAT2250)**, RTX 5090, Fedora 43.
- USB controller: `187c:0551` "AW-ELC", platform_id `0x0812`, firmware 2.1.13, 101 zones.
- Driver applies a color across all 101 zones in ~0.6 s.

## Files

| File | Purpose |
| --- | --- |
| `rgb_weather.py` | Main script: weather fetch + AlienFX USB driver + main loop. |
| `start.sh` | Launcher; checks pyusb, warns about missing udev rule, passes flags through. |
| `install-udev.sh` | One-time setup: writes `/etc/udev/rules.d/99-alienfx.rules` so your user can talk to the controller without sudo. |
| `install-service.sh` | One-time setup: installs the systemd user unit so the loop starts on boot. |
| `rgb-weather.service` | systemd unit installed by `install-service.sh`. |
| `diagnose.sh` | Permission/access diagnostic: runs lsusb, prints device node permissions, reinstalls the udev rule, runs probe. |
| `inspect.sh` | USB descriptor dump: pulls HID descriptor, endpoint info, and report descriptor. Useful when adapting the driver to a new platform_id. |
| `probe_commands.sh` | Legacy artifact from protocol discovery; obsolete now that the real protocol is implemented. Kept for reference. |
| `config.json` | Auto-created on first run. |
| `README.md` | This file. |

## One-time install (Fedora)

```bash
# 1. pyusb
sudo dnf install python3-pyusb

# 2. udev rule (writes MODE=0666 on 187c:0551)
./install-udev.sh

# 3. systemd user service (auto-starts on boot)
./install-service.sh
sudo loginctl enable-linger "$USER"   # so the service runs even before login
```

If the udev step prints `Access denied` errors during probe, run
`./diagnose.sh` — it dumps everything needed to figure out what's blocking.

After step 3 the service is enabled and active. Nothing else is needed; on
reboot it comes up automatically.

## Run

If you installed the service in step 3 above, it's already running. Use
`systemctl --user` to manage it:

```bash
systemctl --user status rgb-weather       # status
systemctl --user restart rgb-weather      # pick up config or code changes
systemctl --user stop rgb-weather         # stop until next reboot
systemctl --user disable --now rgb-weather   # remove autostart entirely
journalctl --user -u rgb-weather -f       # live log
```

For ad-hoc / debugging use, invoke the script directly via `start.sh`. **Stop
the service first** — both processes can't drive the controller at the same
time:

```bash
systemctl --user stop rgb-weather
./start.sh                    # normal: weather-driven loop
./start.sh --probe            # show platform_id, firmware, zone count and exit
./start.sh --cycle            # rotate through 8 test colors
./start.sh --cycle --debug    # same, with USB packet trace
./start.sh --cycle --dwell 5  # 5 s per color instead of default 2 s
./start.sh --raw "03 28"      # send arbitrary hex bytes (CMD_RESET in this example)
systemctl --user start rgb-weather    # remember to bring the service back
```

Ctrl+C stops `start.sh` cleanly.

## Configuration

`config.json` is auto-created next to the script on first run. Defaults:

```json
{
  "provider": "metar",
  "airport": "DFW",
  "latitude": null,
  "longitude": null,
  "poll_interval_seconds": 600
}
```

| Field | Purpose |
| --- | --- |
| `provider` | `"metar"` or `"open-meteo"`. |
| `airport` | 3-letter IATA (auto-prefixed with `K` for US airports) or 4-letter ICAO. |
| `latitude` / `longitude` | If `null`, resolved from `airport`. Used for both Open-Meteo, NOAA alerts, and night detection. |
| `poll_interval_seconds` | Clamped to a 30 s minimum. |
| `night_dim_factor` | Multiplier (0.0–1.0) applied to the RGB color between local sunset and sunrise. Default `0.2` = 20% brightness. |
| `alerts_enabled` | When `true`, polls `api.weather.gov/alerts/active` each tick and pulses the lights if a Tornado Warning, Severe Thunderstorm Warning, etc., is active. |

### Weather providers

- **METAR** (`aviationweather.gov`) — live airport observations. Parses
  `wxString` (active weather like `RA`, `TS`, `SN`) and cloud layers.
  Endpoint requires `&hours=2` to return data; without it, returns
  HTTP 204 empty.
- **Open-Meteo** (`api.open-meteo.com`) — WMO weather codes + cloud cover.
  No API key. Works at arbitrary coordinates if you set `latitude` /
  `longitude` directly.

### Airport → lat/lon resolution (Open-Meteo only)

Order when `latitude`/`longitude` are `null`:

1. `aviationweather.gov` station API.
2. Hardcoded `AIRPORT_COORDS` dict in `rgb_weather.py` (~55 major airports).
3. Abort with a prompt to set `latitude`/`longitude` manually.

Add to `AIRPORT_COORDS` for any airport you use regularly — coordinates
don't change.

## Color mapping

| Condition | Color |
| --- | --- |
| Thunderstorm | purple `(128, 0, 255)` |
| Snow | white `(230, 230, 255)` |
| Freezing precip (Open-Meteo only) | pale cyan `(150, 200, 255)` |
| Rain / drizzle / showers | blue `(0, 80, 255)` |
| Fog / haze / mist | teal `(100, 140, 140)` |
| Overcast | dark gray `(40, 40, 55)` |
| Broken clouds | medium gray `(120, 120, 140)` |
| Scattered / partly cloudy | pale yellow `(220, 180, 80)` |
| Mainly clear | light yellow |
| Clear | bright yellow `(255, 200, 0)` |

Edit `metar_to_color()` / `open_meteo_to_color()` in `rgb_weather.py` to
change the palette.

### Night dimming

Between local sunset and sunrise the chosen color is multiplied by
`night_dim_factor` (default `0.2` → 20% brightness). The cutover is
calculated astronomically from the resolved `latitude`/`longitude` and the
current UTC time — no extra API calls. Log lines tagged `[night-dim]` mean
the dim is currently active.

### NOAA severe-weather alerts

When `alerts_enabled` is true (default), every poll also queries
`api.weather.gov/alerts/active?point=lat,lon`. If any of the recognised
events is active for that point, the lights switch from static to
**pulsing** at the alert's color, overriding the weather color.

| NOAA event | Pulse color |
| --- | --- |
| Tornado Warning | red `(255, 0, 0)` |
| Tornado Watch | deep orange `(255, 80, 0)` |
| Severe Thunderstorm Warning | orange `(255, 100, 0)` |
| Flash Flood Warning | blue `(0, 80, 255)` |
| Severe Thunderstorm Watch | yellow `(255, 200, 0)` |

Highest-priority alert wins. Pulse uses AlienFX `MODE_PULSE` (firmware
animation, ~1.5 s cycle). Pulses are also night-dimmed.

To extend or modify, edit `ALERT_PRIORITY` in `rgb_weather.py`. Order of
the list is the priority order (highest first); add other events from
[NOAA's Alerts vocabulary](https://www.weather.gov/help-map) as needed.

### Heat override

When the base weather is sunny (any color in the yellow palette — clear,
mainly clear, scattered clouds, partly cloudy) **and** the temperature is
≥ 90°F, the color is replaced with a linear gradient from yellow at 90°F
to full red at 130°F. Other weather (rain, fog, thunderstorm, overcast,
etc.) is never overridden — a hot rainy day still shows blue.

Tunable constants at the top of the AlienFX section in `rgb_weather.py`:

| Constant | Default | Meaning |
| --- | --- | --- |
| `HOT_THRESHOLD_F` | `90.0` | Temperature at which override starts. |
| `HOT_FULL_RED_F` | `130.0` | Temperature at which color is fully red. |
| `SUNNY_COLORS` | `{(255,200,0), (220,180,80)}` | Base colors that count as "sunny" — anything else passes through unchanged. |

## AlienFX protocol reference

This is the part of the project that took the most reverse engineering. The
protocol implemented here is ported directly from OpenRGB's
`Controllers/AlienwareController/`.

### Transport

- USB HID, vendor `187C`, product `0550` or `0551` (Dell calls these "G
  Series LED Controller"; Alienware cases call it "AW-ELC").
- Vendor-defined HID class (`UsagePage 0xFF00`), one Input + one Output
  report, **33 bytes each**, **no Report IDs**.
- Commands ride on **Feature reports** (`SET_REPORT` with `wValue=0x0300`).
- Replies come back via `GET_REPORT` (same `wValue`).
- The interrupt endpoints (`0x01` / `0x81`) are present in the descriptor
  but the driver does not use them; everything goes via control transfers.

### Wire format

Every wire packet is exactly 33 bytes:

```
byte 0  : 0x03                  protocol version / packet header
byte 1  : command code          one of CMD_* below
byte 2+ : command-specific args zero-padded to fill 33 bytes
```

A response packet uses `0x83` (`0x80 | 0x03`) at byte 0, mirrors the command
code at byte 1, and provides command-specific result data thereafter.

### Commands used

| Code | Name | Purpose |
| --- | --- | --- |
| `0x20` | `REPORT` | Read firmware info; subcommand `0x00` = firmware version, `0x02` = config (platform_id + zone_count). |
| `0x21` | `USER_ANIM` | Begin / commit an animation block. Subcommands: `NEW=0x0001`, `FINISH_PLAY=0x0003`. Animation slot is always `USER_ANIM_KEYBOARD=0xFFFF` (non-saved). |
| `0x23` | `SELECT_ZONES` | Choose which zones the next ADD_ACTION applies to. Up to 28 zone bytes per packet. |
| `0x24` | `ADD_ACTION` | Apply an action (mode + duration + tempo + RGB) to selected zones. `MODE_COLOR=0x00` is static color. |
| `0x26` | `DIM` | Set brightness percentage (not currently used). |
| `0x28` | `RESET` | Reset controller. |

### Sequence to set all zones to one color

```
1. USER_ANIM(NEW, KEYBOARD, 0)
2. for each batch of up to 28 zones:
       SELECT_ZONES(batch)
       ADD_ACTION(MODE_COLOR, duration=2000, tempo=TEMPO_MAX, R, G, B)
3. USER_ANIM(FINISH_PLAY, KEYBOARD, 0)
```

For 101 zones that's 4 batches → 10 packets total at 60 ms each ≈ 600 ms
per color update. Pacing matches OpenRGB.

### Discovery (REPORT_CONFIG response layout)

Wire bytes after the response prefix (`0x83 0x20 0x02`):

```
[3..4] platform_id (uint16 BE)
[5]    zone_count
```

The driver caches both at startup, so each color update is just the 10
packets above — no re-discovery.

## Hardware notes (Area-51 R8 / AAT2250)

- 5 RGB fans (2× 180 mm front intake, 2× 140 mm bottom, 1× CPU AIO) plus
  Alienware wordmark, Alien-head power button, and a side stadium light.
- These add up to 101 individually-addressable zones from the
  controller's perspective.
- platform_id `0x0812` is not in OpenRGB's `zone_quirks_table` /
  `zone_names_table` — zones are addressed by index `0..100`. If you want
  to set fans differently from chassis lights, the easiest path is to
  cycle a known color through small zone-index ranges and label them by
  what lights up.

## Troubleshooting

| Symptom | Likely cause | Fix |
| --- | --- | --- |
| `usb.core.USBError: [Errno 13] Access denied` | udev rule missing or not reloaded | `./install-udev.sh` |
| `AlienFX USB device 187c:0551 not found` | controller present as a different PID | check `lsusb \| grep -i alien`; update `PID` in `rgb_weather.py` |
| `--probe` shows `zone_count: 0` | `REPORT_CONFIG` returned no zones | controller may need a power-cycle; re-plug or full shutdown (not just reboot) |
| Lights don't change but no errors | wrong report type or `wValue` | confirm `wValue=0x0300` in the source; for a different controller revision try `0x0200` (Output report) |
| Weather fetch transient failure | network blip / aviationweather rate limit | logged; retried on next poll tick |
| METAR returns HTTP 204 | endpoint requires a time window | already handled — `&hours=2` is in the URL |
| Service runs but lights stay stale | controller and `start.sh` both fighting | `systemctl --user stop rgb-weather` before invoking `start.sh`. |
| Service doesn't start at boot | linger not enabled | `sudo loginctl enable-linger "$USER"`; verify with `loginctl show-user "$USER" \| grep Linger`. |

## Sources

- [OpenRGB AlienwareController.cpp](https://github.com/CalcProgrammer1/OpenRGB/blob/master/Controllers/AlienwareController/AlienwareController.cpp) — protocol reference
- [OpenRGB AlienwareController.h](https://github.com/CalcProgrammer1/OpenRGB/blob/master/Controllers/AlienwareController/AlienwareController.h) — command code constants
- [OpenRGB AlienwareControllerDetect.cpp](https://github.com/CalcProgrammer1/OpenRGB/blob/master/Controllers/AlienwareController/AlienwareControllerDetect.cpp) — confirms 187c:0551 is supported
- [Linux kernel alienware-wmi docs](https://docs.kernel.org/wmi/devices/alienware-wmi.html) — confirms RGB is **not** controlled via the kernel WMI driver
- [aviationweather.gov API](https://aviationweather.gov/data/api/) — METAR endpoint
- [Open-Meteo API](https://open-meteo.com/en/docs) — WMO weather codes
- [api.weather.gov](https://www.weather.gov/documentation/services-web-api) — NOAA active-alerts endpoint
