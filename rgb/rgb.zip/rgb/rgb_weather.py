#!/usr/bin/env python3
"""Weather-driven RGB for Alienware AW-ELC (USB 187c:0551).

Stdlib + pyusb. Reads config.json from the same directory (auto-created).

Usage:
    rgb_weather.py              # normal loop: color driven by weather
    rgb_weather.py --cycle      # debug: cycle through test colors
    rgb_weather.py --probe      # open the USB device and exit
    rgb_weather.py --debug      # add USB packet logging (combine with any mode)
    rgb_weather.py --dwell 3    # seconds per color in --cycle (default 2)
"""

import argparse
import datetime as dt
import json
import math
import os
import sys
import time
import urllib.error
import urllib.request

try:
    import usb.core
    import usb.util
except ImportError:
    sys.exit("pyusb not installed — run: sudo dnf install python3-pyusb")


SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(SCRIPT_DIR, "config.json")

DEFAULT_CONFIG = {
    "provider": "metar",          # "metar" or "open-meteo"
    "airport": "DFW",
    "latitude": None,             # auto-resolved from airport if null
    "longitude": None,
    "poll_interval_seconds": 600,
    "night_dim_factor": 0.2,      # multiplier applied between sunset and sunrise
    "alerts_enabled": True,       # poll NOAA alerts and pulse on warnings
}


# --- Config ----------------------------------------------------------------

def load_config():
    if not os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "w") as f:
            json.dump(DEFAULT_CONFIG, f, indent=2)
        print(f"wrote default config to {CONFIG_PATH}", flush=True)
    with open(CONFIG_PATH) as f:
        user_cfg = json.load(f)
    cfg = dict(DEFAULT_CONFIG)
    cfg.update(user_cfg)
    return cfg


# --- Weather ---------------------------------------------------------------

def to_icao(code):
    code = code.strip().upper()
    return "K" + code if len(code) == 3 else code


def _get_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "rgb-weather/1.0"})
    with urllib.request.urlopen(req, timeout=15) as r:
        status = r.status
        body = r.read()
    if not body:
        raise RuntimeError(f"empty body (HTTP {status}) from {url}")
    return json.loads(body)


def fetch_metar(icao):
    data = _get_json(
        f"https://aviationweather.gov/api/data/metar?ids={icao}"
        "&format=json&taf=false&hours=2"
    )
    if not data:
        raise RuntimeError(f"no METAR returned for {icao}")
    return data[0]


# Offline fallback for airport -> (lat, lon) when aviationweather.gov is down.
AIRPORT_COORDS = {
    "KDFW": (32.8968, -97.0380),
    "KJFK": (40.6398, -73.7789),
    "KLAX": (33.9425, -118.4081),
    "KORD": (41.9742, -87.9073),
    "KATL": (33.6407, -84.4277),
    "KSFO": (37.6213, -122.3790),
    "KSEA": (47.4502, -122.3088),
    "KBOS": (42.3656, -71.0096),
    "KMIA": (25.7959, -80.2870),
    "KDEN": (39.8561, -104.6737),
    "KPHX": (33.4342, -112.0116),
    "KLAS": (36.0840, -115.1537),
    "KIAH": (29.9902, -95.3368),
    "KMSP": (44.8848, -93.2223),
    "KDTW": (42.2124, -83.3534),
    "KEWR": (40.6925, -74.1687),
    "KLGA": (40.7769, -73.8740),
    "KDCA": (38.8512, -77.0402),
    "KIAD": (38.9445, -77.4558),
    "KMCO": (28.4312, -81.3081),
    "KCLT": (35.2140, -80.9431),
    "KPHL": (39.8729, -75.2437),
    "KBWI": (39.1754, -76.6683),
    "KSAN": (32.7338, -117.1933),
    "KPDX": (45.5898, -122.5951),
    "KSLC": (40.7899, -111.9791),
    "KSTL": (38.7487, -90.3700),
    "KTPA": (27.9755, -82.5332),
    "KFLL": (26.0726, -80.1527),
    "PHNL": (21.3187, -157.9225),
    "PANC": (61.1744, -149.9963),
    "CYYZ": (43.6777, -79.6248),
    "CYVR": (49.1967, -123.1815),
    "CYUL": (45.4706, -73.7408),
    "MMMX": (19.4361, -99.0719),
    "SBGR": (-23.4356, -46.4731),
    "EGLL": (51.4700, -0.4543),
    "EGKK": (51.1537, -0.1821),
    "LFPG": (49.0097, 2.5479),
    "EHAM": (52.3086, 4.7639),
    "EDDF": (50.0379, 8.5622),
    "EDDM": (48.3538, 11.7861),
    "LSZH": (47.4647, 8.5492),
    "LIRF": (41.8003, 12.2389),
    "LEMD": (40.4839, -3.5680),
    "LEBL": (41.2971, 2.0785),
    "LTFM": (41.2753, 28.7519),
    "OMDB": (25.2528, 55.3644),
    "OTHH": (25.2731, 51.6080),
    "WSSS": (1.3644, 103.9915),
    "VHHH": (22.3080, 113.9185),
    "RJAA": (35.7720, 140.3929),
    "RJTT": (35.5494, 139.7798),
    "RKSI": (37.4602, 126.4407),
    "ZBAA": (40.0801, 116.5846),
    "ZSPD": (31.1434, 121.8052),
    "YSSY": (-33.9399, 151.1753),
    "YMML": (-37.6690, 144.8410),
    "VABB": (19.0896, 72.8656),
    "VIDP": (28.5562, 77.1000),
    "VTBS": (13.6900, 100.7501),
    "FAOR": (-26.1392, 28.2460),
}


def resolve_airport_latlon(icao):
    try:
        data = _get_json(
            f"https://aviationweather.gov/api/data/stations?ids={icao}&format=json"
        )
        if data:
            s = data[0]
            return float(s["lat"]), float(s["lon"])
        reason = "empty response"
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as e:
        reason = f"{type(e).__name__}: {e}"

    if icao in AIRPORT_COORDS:
        print(f"station API unavailable ({reason}); using hardcoded coords for {icao}", flush=True)
        return AIRPORT_COORDS[icao]

    raise RuntimeError(
        f"could not resolve {icao}: station API failed ({reason}) and no hardcoded entry. "
        "Set 'latitude' and 'longitude' in config.json."
    )


def fetch_open_meteo(lat, lon):
    url = (
        "https://api.open-meteo.com/v1/forecast"
        f"?latitude={lat}&longitude={lon}"
        "&current=weather_code,cloud_cover,temperature_2m"
    )
    data = _get_json(url)
    cur = data.get("current") or {}
    if "weather_code" not in cur:
        raise RuntimeError("open-meteo response missing weather_code")
    return cur


HOT_THRESHOLD_F = 90.0
HOT_FULL_RED_F  = 130.0
COOL_COLOR      = (255, 200, 0)   # yellow at HOT_THRESHOLD_F

# Heat override only applies on sunny base conditions — the yellow palette
# returned for clear / mainly clear / scattered / partly cloudy.
SUNNY_COLORS = {(255, 200, 0), (220, 180, 80)}


def hot_override(base_rgb, temp_f):
    """If base is sunny and temp_f >= HOT_THRESHOLD_F, return a yellow→red
    gradient. Else None (no override)."""
    if base_rgb not in SUNNY_COLORS:
        return None
    if temp_f is None or temp_f < HOT_THRESHOLD_F:
        return None
    t = min(temp_f, HOT_FULL_RED_F)
    factor = (t - HOT_THRESHOLD_F) / (HOT_FULL_RED_F - HOT_THRESHOLD_F)
    r, g, b = COOL_COLOR
    return (r, int(round(g * (1 - factor))), b)


def dim_rgb(rgb, factor):
    return tuple(max(0, min(255, int(round(c * factor)))) for c in rgb)


def is_night(lat, lon, now_utc=None):
    """True when the sun is below the horizon at the given (lat, lon)."""
    if now_utc is None:
        now_utc = dt.datetime.now(dt.timezone.utc)
    n = now_utc.timetuple().tm_yday
    decl = math.radians(23.45 * math.sin(math.radians(360 / 365 * (284 + n))))
    hours = now_utc.hour + now_utc.minute / 60 + now_utc.second / 3600
    solar_hour = (hours + lon / 15.0) % 24
    H = math.radians(15 * (solar_hour - 12))
    lat_r = math.radians(lat)
    sin_el = math.sin(lat_r) * math.sin(decl) + math.cos(lat_r) * math.cos(decl) * math.cos(H)
    return sin_el < 0


# NOAA active-alerts. Order = priority (highest first). Each row: (event_name,
# rgb_for_pulse). Anything not listed is ignored.
ALERT_PRIORITY = [
    ("Tornado Warning",             (255, 0, 0)),
    ("Tornado Watch",               (255, 80, 0)),
    ("Severe Thunderstorm Warning", (255, 100, 0)),
    ("Flash Flood Warning",         (0, 80, 255)),
    ("Severe Thunderstorm Watch",   (255, 200, 0)),
]


def fetch_noaa_alerts(lat, lon):
    try:
        return _get_json(f"https://api.weather.gov/alerts/active?point={lat},{lon}")
    except Exception as e:
        print(f"alert fetch failed: {e}", flush=True)
        return None


def pick_alert(alerts_response):
    if not alerts_response:
        return None
    events = {
        (f.get("properties") or {}).get("event", "")
        for f in (alerts_response.get("features") or [])
    }
    for name, color in ALERT_PRIORITY:
        if name in events:
            return name, color
    return None


def metar_to_color(m):
    wx = (m.get("wxString") or "").upper()
    clouds = m.get("clouds") or []

    if "TS" in wx:
        return (128, 0, 255, "thunderstorm")
    if any(c in wx for c in ("SN", "SG", "PL", "GR", "IC")):
        return (230, 230, 255, "snow")
    if any(c in wx for c in ("RA", "DZ", "SH")):
        return (0, 80, 255, "rain")
    if any(c in wx for c in ("FG", "BR", "HZ", "FU", "SA", "DU")):
        return (100, 140, 140, "fog/haze")

    order = ["CLR", "SKC", "CAVOK", "NCD", "FEW", "SCT", "BKN", "OVC"]
    worst = -1
    for c in clouds:
        cov = (c.get("cover") or "").upper()
        if cov in order:
            worst = max(worst, order.index(cov))

    if worst >= order.index("OVC"):
        return (40, 40, 55, "overcast")
    if worst >= order.index("BKN"):
        return (120, 120, 140, "broken clouds")
    if worst >= order.index("SCT"):
        return (220, 180, 80, "scattered clouds")
    return (255, 200, 0, "clear")


def open_meteo_to_color(cur):
    code = int(cur["weather_code"])
    cloud = cur.get("cloud_cover")

    if code in (95, 96, 99):
        return (128, 0, 255, f"thunderstorm (wmo {code})")
    if code in (71, 73, 75, 77, 85, 86):
        return (230, 230, 255, f"snow (wmo {code})")
    if code in (56, 57, 66, 67):
        return (150, 200, 255, f"freezing precip (wmo {code})")
    if code in (51, 53, 55, 61, 63, 65, 80, 81, 82):
        return (0, 80, 255, f"rain (wmo {code})")
    if code in (45, 48):
        return (100, 140, 140, f"fog (wmo {code})")
    if code == 3:
        return (40, 40, 55, "overcast")
    if code == 2:
        return (120, 120, 140, "partly cloudy")
    if code == 1:
        return (220, 180, 80, "mainly clear")
    if code == 0:
        return (255, 200, 0, "clear")

    if isinstance(cloud, (int, float)):
        if cloud >= 85:
            return (40, 40, 55, f"overcast (cc={cloud})")
        if cloud >= 50:
            return (120, 120, 140, f"cloudy (cc={cloud})")
        if cloud >= 20:
            return (220, 180, 80, f"partly cloudy (cc={cloud})")
    return (255, 200, 0, f"clear (wmo {code})")


# --- AlienFX driver (Dell G-series / AW-ELC controller, 187c:0550/0551) ----
# Protocol mirrors OpenRGB's AlienwareController.cpp. Wire format is a 33-byte
# Feature report (no Report ID — descriptor doesn't define one). Every packet
# starts with byte 0x03 (protocol version), then a 1-byte command, then args.

VID = 0x187C
PID = 0x0551
FRAME = 33

CMD_REPORT          = 0x20      # subcommand at byte 2: 0x00 fw, 0x01 status, 0x02 config
CMD_USER_ANIM       = 0x21
CMD_SELECT_ZONES    = 0x23
CMD_ADD_ACTION      = 0x24
CMD_DIM             = 0x26
CMD_RESET           = 0x28

USER_ANIM_NEW         = 0x0001
USER_ANIM_FINISH_PLAY = 0x0003
USER_ANIM_KEYBOARD    = 0xFFFF      # non-saved animation slot

MODE_COLOR  = 0x00      # static color action
MODE_PULSE  = 0x01      # pulsing color action (firmware-driven animation)
TEMPO_MAX   = 0x00FA
DURATION_PULSE = 0x05DC # ~1500 ms pulse cycle

# HID class request — Feature report, Report ID 0, on interface 0
HID_OUT_REQ_TYPE = 0x21
HID_IN_REQ_TYPE  = 0xA1
HID_SET_REPORT   = 0x09
HID_GET_REPORT   = 0x01
WVALUE_FEATURE_ID0 = 0x0300


class AlienFX:
    def __init__(self, debug=False):
        self.debug = debug
        self.dev = usb.core.find(idVendor=VID, idProduct=PID)
        if self.dev is None:
            raise RuntimeError(f"AlienFX USB device {VID:04x}:{PID:04x} not found")
        try:
            if self.dev.is_kernel_driver_active(0):
                self.dev.detach_kernel_driver(0)
        except (usb.core.USBError, NotImplementedError):
            pass
        self.zone_count = 0
        self.platform_id = 0
        self.firmware = ""
        self._discover()

    def _log(self, msg):
        if self.debug:
            print(f"alienfx: {msg}", flush=True)

    def _send(self, payload):
        if len(payload) > FRAME:
            raise ValueError(f"payload {len(payload)}B exceeds frame {FRAME}B")
        buf = bytes(payload) + b"\x00" * (FRAME - len(payload))
        self._log("->  " + " ".join(f"{b:02x}" for b in buf[:12]) + " ...")
        self.dev.ctrl_transfer(
            HID_OUT_REQ_TYPE, HID_SET_REPORT,
            WVALUE_FEATURE_ID0, 0, buf, 1000,
        )
        # OpenRGB's SendHIDReport pacing: 60ms after every command.
        time.sleep(0.06)

    def _recv(self):
        data = bytes(self.dev.ctrl_transfer(
            HID_IN_REQ_TYPE, HID_GET_REPORT,
            WVALUE_FEATURE_ID0, 0, FRAME, 1000,
        ))
        self._log("<-  " + " ".join(f"{b:02x}" for b in data[:12]) + " ...")
        return data

    def report(self, subcommand):
        p = bytearray(FRAME)
        p[0] = 0x03
        p[1] = CMD_REPORT
        p[2] = subcommand
        self._send(p)
        return self._recv()

    def user_anim(self, subcommand, animation, duration):
        p = bytearray(FRAME)
        p[0] = 0x03
        p[1] = CMD_USER_ANIM
        p[2] = (subcommand >> 8) & 0xFF
        p[3] = subcommand & 0xFF
        p[4] = (animation >> 8) & 0xFF
        p[5] = animation & 0xFF
        p[6] = (duration >> 8) & 0xFF
        p[7] = duration & 0xFF
        self._send(p)
        return self._recv()

    def select_zones(self, zones):
        p = bytearray(FRAME)
        p[0] = 0x03
        p[1] = CMD_SELECT_ZONES
        p[2] = 0x01
        p[3] = (len(zones) >> 8) & 0xFF
        p[4] = len(zones) & 0xFF
        for i, z in enumerate(zones):
            p[5 + i] = z & 0xFF
        self._send(p)
        return self._recv()

    def add_action(self, mode, duration, tempo, r, g, b):
        p = bytearray(FRAME)
        p[0] = 0x03
        p[1] = CMD_ADD_ACTION
        p[2] = mode
        p[3] = (duration >> 8) & 0xFF
        p[4] = duration & 0xFF
        p[5] = (tempo >> 8) & 0xFF
        p[6] = tempo & 0xFF
        p[7] = r & 0xFF
        p[8] = g & 0xFF
        p[9] = b & 0xFF
        self._send(p)
        return self._recv()

    def reset_device(self):
        p = bytearray(FRAME)
        p[0] = 0x03
        p[1] = CMD_RESET
        self._send(p)
        return self._recv()

    def _discover(self):
        # REPORT_CONFIG: response wire bytes [3..4] = platform_id, [5] = zone count
        cfg = self.report(0x02)
        self.platform_id = (cfg[3] << 8) | cfg[4]
        self.zone_count = cfg[5]
        # REPORT_FIRMWARE: response wire bytes [3..5] = major.minor.patch
        fw = self.report(0x00)
        self.firmware = f"{fw[3]}.{fw[4]}.{fw[5]}"
        self._log(f"platform_id=0x{self.platform_id:04x} zones={self.zone_count} fw={self.firmware}")

    def _apply_mode(self, mode, duration, tempo, r, g, b):
        if self.zone_count == 0:
            raise RuntimeError("zone_count is 0 — REPORT_CONFIG returned no zones")
        BATCH = 28      # SELECT_ZONES holds 28 zone bytes per packet (offset 5..32)
        self.user_anim(USER_ANIM_NEW, USER_ANIM_KEYBOARD, 0)
        for start in range(0, self.zone_count, BATCH):
            batch = list(range(start, min(start + BATCH, self.zone_count)))
            self.select_zones(batch)
            self.add_action(mode, duration, tempo, r, g, b)
        self.user_anim(USER_ANIM_FINISH_PLAY, USER_ANIM_KEYBOARD, 0)

    def show_color(self, r, g, b):
        self._apply_mode(MODE_COLOR, 2000, TEMPO_MAX, r, g, b)

    def show_pulse(self, r, g, b):
        self._apply_mode(MODE_PULSE, DURATION_PULSE, TEMPO_MAX, r, g, b)

    def raw(self, hex_bytes):
        if isinstance(hex_bytes, str):
            cleaned = hex_bytes.replace(",", " ").replace("0x", "").split()
            payload = bytes(int(b, 16) for b in cleaned)
        else:
            payload = bytes(hex_bytes)
        self._send(payload)
        try:
            resp = self._recv()
            return resp[0] if len(resp) else -1
        except usb.core.USBError as e:
            self._log(f"recv err: {e}")
            return -1

    def close(self):
        try:
            usb.util.dispose_resources(self.dev)
        except Exception:
            pass


def apply_color(rgb, debug=False):
    r, g, b = rgb
    fx = AlienFX(debug=debug)
    try:
        fx.show_color(r, g, b)
    finally:
        fx.close()


def apply_pulse(rgb, debug=False):
    r, g, b = rgb
    fx = AlienFX(debug=debug)
    try:
        fx.show_pulse(r, g, b)
    finally:
        fx.close()


# --- Modes -----------------------------------------------------------------

CYCLE_COLORS = [
    ("red",     (255, 0, 0)),
    ("yellow",  (255, 255, 0)),
    ("green",   (0, 255, 0)),
    ("cyan",    (0, 255, 255)),
    ("blue",    (0, 0, 255)),
    ("magenta", (255, 0, 255)),
    ("white",   (255, 255, 255)),
    ("off",     (0, 0, 0)),
]


def cycle(debug, dwell):
    print(f"cycle mode: {len(CYCLE_COLORS)} colors x {dwell}s  (Ctrl+C to stop)", flush=True)
    while True:
        for name, rgb in CYCLE_COLORS:
            print(f"[{time.strftime('%H:%M:%S')}] {name} rgb={rgb}", flush=True)
            try:
                apply_color(rgb, debug=debug)
            except Exception as e:
                print(f"error: {e}", flush=True)
            time.sleep(dwell)


def _make_poll_fn(cfg):
    provider = cfg["provider"].lower()
    icao = to_icao(cfg["airport"])
    lat = cfg.get("latitude")
    lon = cfg.get("longitude")
    if lat is None or lon is None:
        try:
            lat, lon = resolve_airport_latlon(icao)
            print(f"resolved {icao} -> lat={lat}, lon={lon}", flush=True)
        except RuntimeError as e:
            print(f"warning: could not resolve lat/lon: {e}", flush=True)

    if provider == "metar":
        def poll():
            m = fetch_metar(icao)
            r, g, b, label = metar_to_color(m)
            temp_c = m.get("temp")
            temp_f = (temp_c * 9 / 5 + 32) if temp_c is not None else None
            return r, g, b, label, m.get("rawOb", ""), temp_f
        loc_label = icao if lat is None else f"{icao} ({lat:.3f},{lon:.3f})"
        return provider, loc_label, poll, lat, lon

    if provider == "open-meteo":
        if lat is None:
            raise RuntimeError("open-meteo requires lat/lon — set them in config or fix airport resolution")

        def poll():
            cur = fetch_open_meteo(lat, lon)
            r, g, b, label = open_meteo_to_color(cur)
            temp_c = cur.get("temperature_2m")
            temp_f = (temp_c * 9 / 5 + 32) if temp_c is not None else None
            detail = f"code={cur.get('weather_code')} cloud_cover={cur.get('cloud_cover')}"
            return r, g, b, label, detail, temp_f
        return provider, f"{icao} ({lat:.3f},{lon:.3f})", poll, lat, lon

    raise ValueError(f"unknown provider: {cfg['provider']!r} (use 'metar' or 'open-meteo')")


def loop(debug):
    cfg = load_config()
    interval = max(30, int(cfg["poll_interval_seconds"]))
    night_dim = float(cfg.get("night_dim_factor", 0.2))
    alerts_enabled = bool(cfg.get("alerts_enabled", True))

    provider, label, poll, lat, lon = _make_poll_fn(cfg)
    print(f"rgb-weather: provider={provider} loc={label} every {interval}s "
          f"(night_dim={night_dim}, alerts={'on' if alerts_enabled else 'off'})",
          flush=True)

    while True:
        try:
            r, g, b, condition, detail, temp_f = poll()

            override = hot_override((r, g, b), temp_f)
            if override is not None:
                r, g, b = override
                condition = f"hot {temp_f:.0f}F (base: {condition})"

            alert = None
            if alerts_enabled and lat is not None and lon is not None:
                alert = pick_alert(fetch_noaa_alerts(lat, lon))

            night = lat is not None and lon is not None and is_night(lat, lon)
            night_tag = " [night-dim]" if night else ""
            ts = time.strftime('%H:%M:%S')

            if alert is not None:
                aname, argb = alert
                if night:
                    argb = dim_rgb(argb, night_dim)
                print(f"[{ts}] ALERT: {aname} pulse={tuple(argb)}{night_tag}", flush=True)
                apply_pulse(argb, debug=debug)
            else:
                if night:
                    r, g, b = dim_rgb((r, g, b), night_dim)
                temp_str = f"{temp_f:.0f}F" if temp_f is not None else "?"
                print(f"[{ts}] {condition} {temp_str} rgb=({r},{g},{b}){night_tag}  {detail}", flush=True)
                apply_color((r, g, b), debug=debug)
        except urllib.error.URLError as e:
            print(f"weather fetch failed: {e}", flush=True)
        except Exception as e:
            print(f"error: {e}", flush=True)

        time.sleep(interval)


def probe():
    fx = AlienFX(debug=True)
    print(f"device opened: VID={VID:04x} PID={PID:04x}", flush=True)
    print(f"  platform_id: 0x{fx.platform_id:04x}", flush=True)
    print(f"  firmware:    {fx.firmware}", flush=True)
    print(f"  zone_count:  {fx.zone_count}", flush=True)
    fx.close()


def main():
    ap = argparse.ArgumentParser(description="Weather-driven RGB for Alienware AW-ELC")
    ap.add_argument("--cycle", action="store_true", help="cycle through test colors (debug)")
    ap.add_argument("--probe", action="store_true", help="open the USB device and exit")
    ap.add_argument("--debug", action="store_true", help="log USB packets / status reads")
    ap.add_argument("--dwell", type=float, default=2.0, help="seconds per color in --cycle")
    ap.add_argument("--raw", type=str, default=None,
                    help="send arbitrary hex bytes as a command and print response, e.g. --raw '02 07 04'")
    args = ap.parse_args()

    if args.probe:
        probe()
        return
    if args.raw is not None:
        fx = AlienFX(debug=True)
        try:
            resp = fx.raw(args.raw)
            print(f"response first byte: 0x{resp:02x}" if resp >= 0 else "no response", flush=True)
        finally:
            fx.close()
        return
    if args.cycle:
        cycle(debug=args.debug, dwell=args.dwell)
        return
    loop(debug=args.debug)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
