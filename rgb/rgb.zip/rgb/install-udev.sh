#!/usr/bin/env bash
# One-time setup: install udev rule so your user can talk to the AlienFX
# controller (187c:0551) without sudo, then re-trigger udev so the rule
# applies to the already-plugged internal device.

set -euo pipefail

RULE_FILE=/etc/udev/rules.d/99-alienfx.rules
RULE='SUBSYSTEM=="usb", ATTRS{idVendor}=="187c", ATTRS{idProduct}=="0551", MODE="0666"'

echo "Writing $RULE_FILE (sudo required)..."
echo "$RULE" | sudo tee "$RULE_FILE" >/dev/null

echo "Reloading udev rules..."
sudo udevadm control --reload-rules

echo "Re-triggering udev for Alienware devices..."
sudo udevadm trigger --action=add --attr-match=idVendor=187c

echo
echo "Done. Now run:"
echo "    ./start.sh --probe"
echo "and expect 'initial status byte: 0x10' (or 0x11) instead of Access denied."
